chrome.storage.sync.get(['enabled', 'words'], ({ enabled, words }) => {
  if (!enabled || !words) return;

  const wordList = words.split(/\s+/).filter(w => w.length > 0);
  if (wordList.length === 0) return;

  // Define color themes (background + text)
  const colorPairs = [
  { bg: '#e74c3c', color: '#ffffff' }, // red bg, white text
  { bg: '#2ecc71', color: '#ffffff' }, // green bg, white text
  { bg: '#ff6f61', color: '#ffffff' }, // coral bg, white text
  { bg: '#f1c40f', color: '#ffffff' }, // yellow bg, white text (updated)
  { bg: '#9b59b6', color: '#ffffff' }, // purple bg, white text
  { bg: '#e67e22', color: '#000000' }, // orange bg, black text
  { bg: '#1abc9c', color: '#000000' }, // teal bg, black text
  { bg: '#34495e', color: '#ffffff' }  // dark blue bg, white text
];


  const regexes = wordList.map((word, index) => {
    const escaped = word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`\\b(${escaped})\\b`, 'gi');
    return { regex, index };
  });

  const walk = (node) => {
    if (
      node.nodeType === 3 &&
      node.parentNode &&
      !node.parentNode.closest('script, style, noscript, textarea, input') &&
      !node.parentNode.classList.contains('multi-highlighted')
    ) {
      let text = node.nodeValue;
      let hasMatch = false;

      regexes.forEach(({ regex, index }) => {
        if (regex.test(text)) {
          hasMatch = true;
          text = text.replace(regex, (match) => {
            const color = colorPairs[index % colorPairs.length];
            return `<mark class="multi-highlighted" style="
              background: ${color.bg};
              color: ${color.color};
              font-weight: bold;
              padding: 1px 3px;
              border-radius: 3px;
            ">${match}</mark>`;
          });
        }
      });

      if (hasMatch) {
        const span = document.createElement('span');
        span.innerHTML = text;
        node.parentNode.replaceChild(span, node);
      }
    } else if (node.nodeType === 1 && node.childNodes) {
      for (let i = 0; i < node.childNodes.length; i++) {
        walk(node.childNodes[i]);
      }
    }
  };

  walk(document.body);
});
