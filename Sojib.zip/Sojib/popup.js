const currentVersion = chrome.runtime.getManifest().version;
const versionUrl = 'https://raw.githubusercontent.com/sojibrema1/Multi-Highlighter/refs/heads/main/version.txt';
const zipUrl = 'https://github.com/sojibrema1/Multi-Highlighter/raw/main/Sojib.zip';

// Update check
async function checkForUpdate() {
  try {
    const response = await fetch(versionUrl + '?t=' + Date.now());
    if (!response.ok) throw new Error('Failed to fetch version');
    const latestVersion = (await response.text()).trim();

    if (latestVersion !== currentVersion) {
      if (confirm(`Update available!\n\nCurrent: ${currentVersion}\nLatest: ${latestVersion}\n\nDownload update?`)) {
        chrome.downloads.download({
          url: zipUrl,
          filename: 'Multi-Highlighter-Update.zip',
        }, (downloadId) => {
          if (chrome.runtime.lastError) {
            alert('Download failed: ' + chrome.runtime.lastError.message);
          }
        });
      }
    } else {
      console.log('Extension is up to date');
    }
  } catch (error) {
    console.error('Update check failed:', error);
  }
}

// DOM Elements
let switcher, textarea, modeRadios, colorPicker, colorPickerContainer, hexInput, textColorSelect;

// Show/hide color picker
function toggleColorPickerVisibility(mode) {
  if (colorPickerContainer) {
    colorPickerContainer.style.display = mode === 'single' ? 'block' : 'none';
  }
}

// Remove highlights
function removeHighlightScript() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]?.id) return;
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => {
        const highlights = document.querySelectorAll('mark.multi-highlighted');
        highlights.forEach(mark => {
          const parent = mark.parentNode;
          parent.replaceChild(document.createTextNode(mark.textContent), mark);
          parent.normalize();
        });
      }
    });
  });
}

// Highlight words
function highlightWords() {
  chrome.storage.local.get(['words', 'highlightMode', 'singleColor', 'textColor'], ({ words, highlightMode, singleColor, textColor }) => {
    if (!words) return;

    const wordList = words.trim().split(/\s+/).filter(Boolean);
    if (wordList.length === 0) return;

    const regexSource = wordList.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]?.id) return;

      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          const marks = document.querySelectorAll('mark.multi-highlighted');
          marks.forEach(m => {
            const p = m.parentNode;
            p.replaceChild(document.createTextNode(m.textContent), m);
            p.normalize();
          });
        }
      }).then(() => {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: (regexSource, wordList, highlightMode, singleColor, textColor) => {
            const regex = new RegExp(`\\b(${regexSource})\\b`, 'gi');
            const colorStyles = [
              { bg: '#e74c3c', color: '#fff' },
              { bg: '#2ecc71', color: '#fff' },
              { bg: '#3498db', color: '#fff' },
              { bg: '#f1c40f', color: '#000' },
              { bg: '#9b59b6', color: '#fff' },
              { bg: '#e67e22', color: '#fff' },
              { bg: '#1abc9c', color: '#fff' }
            ];

            const getStyleForWord = (word) => {
              if (highlightMode === 'single') {
                return { bg: singleColor || '#ffff00', color: textColor || '#000' };
              } else {
                const index = wordList.findIndex(w => w.toLowerCase() === word.toLowerCase());
                return colorStyles[index % colorStyles.length];
              }
            };

            const walk = (node) => {
              if (
                node.nodeType === 3 &&
                node.parentNode &&
                !node.parentNode.closest('script, style, textarea, input, noscript') &&
                !node.parentNode.classList.contains('multi-highlighted')
              ) {
                if (regex.test(node.nodeValue)) {
                  const span = document.createElement('span');
                  span.innerHTML = node.nodeValue.replace(regex, (match) => {
                    const style = getStyleForWord(match);
                    return `<mark class="multi-highlighted" style="background: ${style.bg}; color: ${style.color}; font-weight: bold; padding: 1px 3px; border-radius: 4px; display: inline-block; white-space: nowrap; font-size: 90%; line-height: 1.2;">${match}</mark>`;
                  });
                  node.parentNode.replaceChild(span, node);
                }
              } else if (node.nodeType === 1 && node.childNodes) {
                node.childNodes.forEach(child => walk(child));
              }
            };

            walk(document.body);
          },
          args: [regexSource, wordList, highlightMode, singleColor, textColor]
        });
      });
    });
  });
}

// Toggle highlight
function triggerHighlight() {
  chrome.storage.local.get(['enabled', 'highlightMode'], ({ enabled, highlightMode }) => {
    const mode = highlightMode || 'all';
    if (enabled) {
      chrome.storage.local.set({ highlightMode: mode }, () => {
        highlightWords();
      });
    } else {
      removeHighlightScript();
    }
  });
}

// On load
window.onload = () => {
  switcher = document.getElementById('switcher');
  textarea = document.getElementById('highlight-words');
  modeRadios = document.getElementsByName('highlightMode');
  colorPicker = document.getElementById('colorPicker');
  colorPickerContainer = document.getElementById('colorPickerContainer');
  hexInput = document.getElementById('hexValue');
  textColorSelect = document.getElementById('textColorSelect');

  checkForUpdate();

  chrome.storage.local.get(['enabled', 'words', 'highlightMode', 'singleColor', 'textColor'], ({ enabled = false, words = '', highlightMode = 'all', singleColor = '#ffff00', textColor = '#000000' }) => {
    chrome.storage.local.set({ enabled, words, highlightMode, singleColor, textColor });

    switcher.setAttribute('data-on', enabled.toString());
    textarea.value = words;
    document.querySelector(`input[name="highlightMode"][value="${highlightMode}"]`).checked = true;
    toggleColorPickerVisibility(highlightMode);
    colorPicker.value = singleColor;
    hexInput.value = singleColor;
    if (textColorSelect) textColorSelect.value = textColor;

    triggerHighlight();
  });

  textarea.addEventListener('input', () => {
    const val = textarea.value.trim();
    chrome.storage.local.set({ words: val }, () => {
      triggerHighlight();
    });
  });

  switcher.addEventListener('click', () => {
    const isOn = switcher.getAttribute('data-on') === 'true';
    const newState = !isOn;
    switcher.setAttribute('data-on', newState.toString());
    chrome.storage.local.set({ enabled: newState }, () => {
      triggerHighlight();
    });
  });

  modeRadios.forEach(radio => {
    radio.addEventListener('change', () => {
      const selectedMode = document.querySelector('input[name="highlightMode"]:checked').value;
      chrome.storage.local.set({ highlightMode: selectedMode }, () => {
        toggleColorPickerVisibility(selectedMode);
        triggerHighlight();
      });
    });
  });

  colorPicker.addEventListener('input', () => {
    const selectedColor = colorPicker.value;
    hexInput.value = selectedColor;
    chrome.storage.local.set({ singleColor: selectedColor }, () => {
      triggerHighlight();
    });
  });

  hexInput.addEventListener('input', () => {
    if (/^#([0-9A-Fa-f]{3}){1,2}$/.test(hexInput.value)) {
      colorPicker.value = hexInput.value;
      chrome.storage.local.set({ singleColor: hexInput.value }, () => {
        triggerHighlight();
      });
    }
  });

  if (textColorSelect) {
    textColorSelect.addEventListener('change', () => {
      const selectedTextColor = textColorSelect.value;
      chrome.storage.local.set({ textColor: selectedTextColor }, () => {
        triggerHighlight();
      });
    });
  }
};
