const switcher = document.getElementById('switcher');
const textarea = document.getElementById('highlight-words');

// Remove existing highlights
function removeHighlightScript() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]?.id) return;
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => {
        const highlights = document.querySelectorAll('mark.multi-highlighted');
        highlights.forEach(mark => {
          const parent = mark.parentNode;
          parent.replaceChild(document.createTextNode(mark.textContent), mark);
          parent.normalize();
        });
      }
    });
  });
}

// Highlight matching words
function highlightWords() {
  chrome.storage.local.get(['words'], ({ words }) => {
    if (!words) return;

    const wordList = words.trim().split(/\s+/).filter(Boolean);
    if (wordList.length === 0) return;

    const regexSource = wordList
      .map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
      .join('|');

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]?.id) return;

      // Step 1: Remove old highlights
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          const marks = document.querySelectorAll('mark.multi-highlighted');
          marks.forEach(m => {
            const p = m.parentNode;
            p.replaceChild(document.createTextNode(m.textContent), m);
            p.normalize();
          });
        }
      }).then(() => {
        // Step 2: Add new highlights
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: (regexSource, wordList) => {
            const regex = new RegExp(`\\b(${regexSource})\\b`, 'gi');
            const colorStyles = [
              { bg: '#e74c3c', color: '#fff' },
              { bg: '#2ecc71', color: '#fff' },
              { bg: '#3498db', color: '#fff' },
              { bg: '#f1c40f', color: '#000' },
              { bg: '#9b59b6', color: '#fff' },
              { bg: '#e67e22', color: '#fff' },
              { bg: '#1abc9c', color: '#fff' }
            ];

            const getStyleForWord = (word) => {
              const index = wordList.findIndex(w => w.toLowerCase() === word.toLowerCase());
              return colorStyles[index % colorStyles.length];
            };

            const walk = (node) => {
              if (
                node.nodeType === 3 &&
                node.parentNode &&
                !node.parentNode.closest('script, style, textarea, input, noscript') &&
                !node.parentNode.classList.contains('multi-highlighted')
              ) {
                if (regex.test(node.nodeValue)) {
                  const span = document.createElement('span');
                  span.innerHTML = node.nodeValue.replace(regex, (match) => {
                    const style = getStyleForWord(match);
                    return `<mark class="multi-highlighted" style="
                      background: ${style.bg};
                      color: ${style.color};
                      font-weight: bold;
                      padding: 1px 3px;
                      border-radius: 4px;
                      display: inline-block;
                      white-space: nowrap;
                      font-size: 90%;
                      line-height: 1.2;
                    ">${match}</mark>`;
                  });
                  node.parentNode.replaceChild(span, node);
                }
              } else if (node.nodeType === 1 && node.childNodes) {
                node.childNodes.forEach(child => walk(child));
              }
            };

            walk(document.body);
          },
          args: [regexSource, wordList]
        });
      });
    });
  });
}

// Trigger highlight or remove based on toggle
function triggerHighlight() {
  chrome.storage.local.get(['enabled'], ({ enabled }) => {
    if (enabled) {
      highlightWords();
    } else {
      removeHighlightScript();
    }
  });
}

// Load state and words on popup open
window.onload = () => {
  chrome.storage.local.get(['enabled', 'words'], ({ enabled, words }) => {
    switcher.setAttribute('data-on', enabled ? 'true' : 'false');
    textarea.value = words || '';
    triggerHighlight();
  });
};

// Save word list when user types
textarea.addEventListener('input', () => {
  const val = textarea.value.trim();
  chrome.storage.local.set({ words: val }, () => {
    triggerHighlight();
  });
});

// Toggle switch click handler
switcher.addEventListener('click', () => {
  const isOn = switcher.getAttribute('data-on') === 'true';
  const newState = !isOn;
  switcher.setAttribute('data-on', newState.toString());
  chrome.storage.local.set({ enabled: newState }, () => {
    triggerHighlight();
  });
});
