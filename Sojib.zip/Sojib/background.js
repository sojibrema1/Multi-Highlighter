const CURRENT_VERSION = chrome.runtime.getManifest().version;
const VERSION_URL = "https://raw.githubusercontent.com/sojibrema1/Multi-Highlighter/main/version.txt";
const DOWNLOAD_URL = "https://raw.githubusercontent.com/sojibrema1/Multi-Highlighter/main/Sojib.zip";

let updateNotificationId = null;

function compareVersions(a, b) {
  const pa = a.split('.').map(Number);
  const pb = b.split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const diff = (pa[i] || 0) - (pb[i] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

async function checkForUpdateInBackground() {
  try {
    const res = await fetch(VERSION_URL);
    const latest = (await res.text()).trim();
    if (compareVersions(latest, CURRENT_VERSION) > 0 && !updateNotificationId) {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: '🔄 Update Available!',
        message: `New version ${latest} is available.\nClick to download.`,
        priority: 2
      }, (notificationId) => {
        updateNotificationId = notificationId;
      });
    }
  } catch (e) {
    console.error("Background update check failed:", e);
  }
}

// Listen for notification clicks just once
chrome.notifications.onClicked.addListener((notificationId) => {
  if (notificationId === updateNotificationId) {
    chrome.tabs.create({ url: DOWNLOAD_URL });
    chrome.notifications.clear(notificationId);
    updateNotificationId = null;
  }
});

// Run once when the extension starts
chrome.runtime.onStartup.addListener(checkForUpdateInBackground);

// Also run once when extension is installed/updated
chrome.runtime.onInstalled.addListener(checkForUpdateInBackground);

// Optional: check once daily
chrome.alarms.create('dailyUpdateCheck', { periodInMinutes: 1440 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'dailyUpdateCheck') {
    checkForUpdateInBackground();
  }
});
